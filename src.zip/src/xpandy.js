// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Xpandy 2.0
// usage const expander = new Xpandy('.Feed', {});

// TODO: Look into accessibility

import configFactory from "./config";
import stateFactory from "./state";

const Xpandy = (container, config) => {
  // ------------------------------------------------

  // Check if Xpandy has already been initialized on this container

  // TODO: rewrite this part a little cleaner
  let elements = [];

  if (typeof container === "string") {
    elements = document.querySelectorAll(container);
  } else if (container && typeof container === "object" && container.length) {
    elements = container;
  }

  // -------------------------------------------------

  // TODO: Consider scoping the config and state to Xpandy
  const manageConfig = configFactory(config);
  const manageState = stateFactory();

  const createPreview = config => {
    // TODO: add option to the config to manually set this config
    // this should be the default... potentially this markup should be in the config
    // and createPreview might go away
    const previewHTML = `
        <div class="Details-expander">
            ${config.arrow ? `<div class="Details-arrow"></div>` : ``}
            <div class="Details-expander-inner">
                <div class="Details-content">
                    <div class="Details-close--relative">
                        <span class="Details-close"></span>
                    </div>
                    <div class="Details-content-body"></div>
                </div>
            </div>
        </div>
        `;

    return document.createRange().createContextualFragment(previewHTML);
  };

  const togglePreview = obj => {
    let { element, el } = obj;

    const config = manageConfig.getConfig(element);
    const state = manageState.getState(element);

    // -----------------------------------------
    // Case #1
    // There are no activeItems- so we are free to go ahead and open one
    if (!state.activeItems) {
      return openPreview({ element, el });
    }

    // -----------------------------------------
    // Case #2
    // The active item is the one clicked on

    // Potentially allow for multiple open items... not in the same row
    // TODO: No IE support for Array.includes() Look into use of .some()
    const itemIsActive = state.activeItems.includes(el);

    if (itemIsActive) {
      return closePreview({ element, el });
    }

    // -----------------------------------------
    // Case #3
    // A new item is clicked on, and there are activeItems

    // Check to see if any activeItems are on the same row
    // Check to see if more than one preview row can be active at a time

    // The goal is to get an array of items on the same row... there should be either 1 or 0
    const itemOnSameRow = state.activeItems.find(
      item => item.offsetTop === el.offsetTop
    );

    // if autoCloseOnOpen we will open or update
    // if not autoCloseOnOpen we will open, close, or update

    // If there are any items on the same row then we can just update it... no need for further checks
    // TODO: Check that if an empty array is booleey false
    if (itemOnSameRow) {
      return updatePreview({ element, el, itemOnSameRow });
    }

    // If you cannot have more than one open item... close all the previews
    if (!config.autoCloseOnOpen) {
      closePreview({ element });
    }

    // If there are no items on the same row we will create a new one
    return openPreview({ element, el });
  };

  const closePreview = obj => {
    let { element, el } = obj;

    // Setup
    const config = manageConfig.getConfig(element);
    const state = manageState.getState(element);

    // If the state is animating already...
    if (state.isAnimating) return state;

    state.isAnimating = true;

    // if `el` is set, then just close the preview for that item
    // -> we will have to get the preview that is being used for that row
    // if `el` is not set then we will close all previews
    const itemsToClose = el ? [el] : state.activeItems;

    itemsToClose.forEach(item => {
      // TODO: offsetTop gives you the distance from the closest relatively positioned parent
      //       it might not cause issues, so i'm leaving it for now, if in the future it does
      //       i will create a getBoundingCLientRect() sort of function to get the real offsetTop
      const previewOnSameRow = state._previewElements.find(
        preview => preview.parentItem.offsetTop === item.offsetTop
      );

      // previewOnSameRow.parentItem.classList.add("Details--animateOut");

      // -----------------------------------------------------
      // This part is a bit of some black magic

      let arrow = previewOnSameRow.preview.querySelector(".Details-arrow");

      const closePreviewElement = () => {
        // TODO: it isn't great that these items are scoped weird...

        // Hide overflow for this next part
        previewOnSameRow.preview.style.overflow = "hidden";

        // Reduce the height to 0... since we are closing it
        previewOnSameRow.preview.style.height = "";

        // TODO: handle how I will give items their height
        //       below is a placeholden so i can move on
        previewOnSameRow.parentItem.style.height = "300px";

        // TODO: ensure this is working correctly
        // This should remove itself...
        if (config.arrow) {
          arrow.removeEventListener(
            "transitionend",
            closePreviewElement,
            false
          );
        }
      };

      const cleanUpClose = () => {
        // TODO: it isn't great that these items are scoped weird...

        // previewOnSameRow.preview.classList.remove("Details--animateIn");
        // previewOnSameRow.preview.classList.remove("Details--animateOut");

        previewOnSameRow.parentItem.classList.remove("Details--expanded");

        state.container.classList.remove("Feed--is-expanded");
        previewOnSameRow.preview.style.overflow = "";

        // This is not supported in IE11...
        previewOnSameRow.preview.remove();

        // We are all done now, remove isAnimating state
        state.isAnimating = false;

        previewOnSameRow.preview.removeEventListener(
          "transitionend",
          cleanUpClose,
          false
        );
      };

      if (config.arrow) {
        // If there is an arrow. Then we want to remove it first.
        // Remove the active state on the arrow and after it has finished transitioning out of view
        // we can trigger the removal of the preview element
        arrow.classList.remove("is-active");

        arrow.addEventListener("transitionend", closePreviewElement, false);
        arrow.style.left = "0px";
        setTimeout(() => (arrow.style.left = "30px"), 0);
      } else {
        closePreviewElement();
      }

      previewOnSameRow.preview.addEventListener(
        "transitionend",
        cleanUpClose,
        false
      );
    });

    // If `el` is getting passed into this function
    // then that means we only want to close one item
    // so use .filter() to remove that item from state.activeItems
    // else if `el` is not getting passed in, then close them all
    state.activeItems = el ? state.activeItems.filter(item => item !== el) : [];

    // Remove from _previveElements the preview we are closing
    // If there is el we just remove the one... if this is a global close then it doesn't matter
    // and we can dump the whole thing
    state._previewElements = el
      ? state._previewElements.filter(item => item.parentItem !== el)
      : [];

    config.callbacks.onClose();

    return state;
  };

  const openPreview = obj => {
    let { element, el } = obj;

    // Setup
    const state = manageState.getState(element);
    const config = manageConfig.getConfig(element);

    if (state.isAnimating) return state;

    state.isAnimating = true;

    // Add the preview item to the el about to be opened
    el.appendChild(state._preview.cloneNode(true));

    const preview = el.querySelector(".Details-expander");
    const previewBody = el.querySelector(".Details-content-body");
    const itemContent = el.querySelector(".Feed-details");

    // Hide overflow
    preview.style.overflow = "hidden";

    const previewAnimationEnd = () => {
      preview.style.overflow = "";

      state.container.classList.add("Feed--is-expanded");

      // We are all done now, remove isAnimating state
      state.isAnimating = false;

      preview.removeEventListener("transitionend", previewAnimationEnd, false);
    };

    // NOTE: TODO: There was once a delay for the arrow to popup... i'm skipping that so i can move on

    preview.addEventListener("transitionend", previewAnimationEnd, false);

    // TODO: This might not be the best... look into other ways to insert the HTML
    previewBody.innerHTML = itemContent.innerHTML;
    // preview.classList.add("Details--animateIn");

    const previewHeight = previewBody.getBoundingClientRect().height;
    const elementHeight = previewHeight + el.clientHeight;

    // Prep the element by setting the existing height
    el.style.height = el.clientHeight + "px";

    // These are in timeouts because browser become dumb trying to be smart
    // and get the ordering wrong
    setTimeout(() => (preview.style.height = previewHeight + "px"), 0);
    setTimeout(() => (el.style.height = elementHeight + "px"), 0);

    // Add the item to the arrow of active `_previewElements`
    state._previewElements.push({
      preview: preview,
      parentItem: el
    });

    state.activeItems.push(el);

    config.callbacks.onOpen();

    return state;
  };

  const updatePreview = obj => {
    let { el, element, itemOnSameRow } = obj;

    const state = manageState.getState(element);
    const config = manageConfig.getConfig(element);

    // If we are in the middle of animating...
    if (state.isAnimating) return state;

    state.isAnimating = true;

    const previewWrapper = el.querySelector(".Feed-details");

    const previewOnSameRow = state._previewElements.find(
      preview => preview.parentItem.offsetTop === el.offsetTop
    );

    let previewBody = previewOnSameRow.preview.querySelector(
      ".Details-content-body"
    );

    // REMOVE ACTIVE ITEM FROM THIS ROW AND PUSH THE NEW ONE
    // TODO: ^^^
    state.activeItems.push(el);

    el.classList.add("Details--expanded");

    itemOnSameRow.classList.remove("Details--expanded");

    // TODO: this needs to be removed after the transition
    previewOnSameRow.preview.style.overflow = "hidden";

    // TODO: Check if this is the right way to do it... maybe clone?
    previewBody.innerHTML = previewWrapper.innerHTML;

    // ----------------------------

    const elThumbnail = el.querySelector(".Feed-thumbnail");

    const previewHeight = previewBody.getBoundingClientRect().height;
    const elementHeight = previewHeight + elThumbnail.clientHeight;

    previewOnSameRow.preview.style.height = previewHeight + "px";
    previewOnSameRow.parentItem.style.height = elementHeight + "px";

    // ----------------------------

    // previewOnSameRow.parentItem.style.height = elementHeight + "px";

    // TODO: Add a callback after the transition ends... for now it isn't needed
    // TODO: Update the arrow
    // TODO: This above callback will need the below cleanup code too

    state.isAnimating = false;

    config.callbacks.onUpdate();

    return state;
  };

  const returnInstanceOrInitialize = element => {
    // And check if an instance exists... and just return it from here
    if (manageState.stateExists(element)) {
      return manageState.getState(element);
    }

    // Fetch the current config instance
    // TODO: test that the config can be updated and
    //       that those changes are reflected in the app
    const config = manageConfig.register(element);

    // TODO: createPreview... put this markup in the config
    //        as mentioned in the TODO written in createPreview
    // TODO: Make _preview private
    // TODO: seperate state into it's own file
    //       and consider how to get config into state
    //       there might be an initializeState part and an manageState.getState part
    //       kinda like how config is working now
    const state = manageState.register(element);

    state.items = config.items
      ? Array.from(element.querySelectorAll(config.items))
      : Array.from(element.children);

    state._preview = createPreview(config);

    element.classList.add("Xpandy-isActive");

    // --------------------------------------
    // Setup the events
    // --------------------------------------

    // --------------------------------------
    // Click Thumbnail Events

    state.items.forEach(el => {
      // TODO: make this class an option, or a default and use the config to query it
      // TODO: ERROR_REPORTING... if this doesn't exist
      let thumbnail = el.querySelector(".Feed-thumbnail");

      // TODO: See if there are better ways to do event listeners... for fun
      // TODO: make sure the `el` is getting passed in
      thumbnail.addEventListener("click", () => togglePreview({ element, el }));
    });

    // --------------------------------------
    // Window resize events

    // The resize event from the top... it might not be the best way to handle resize events... also IE11
    // We will close the preview on resize... at at later date we can come back to this isssue
    // it would be nice to keep the preview pane open on resize... but that is messy
    window.addEventListener("resize", () => closePreview({ element }));

    // --------------------------------------
    // Close X Events

    // Using query selector all so in the future I can tag other elements with the close class
    Array.from(state._preview.querySelectorAll(".Details-close")).forEach(el =>
      el.addEventListener("click", () => closePreview({ element, el }))
    );

    // --------------------------------------

    // Trigger callbacks
    config.callbacks.onInit();

    return state;
  };

  // Return the Xpanders
  return Array.from(elements).map(returnInstanceOrInitialize);
};

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

export default Xpandy;
