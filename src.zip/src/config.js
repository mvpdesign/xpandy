const configFactory = userConfig => {
  // TODO: Check if Object.assign deep merges the callbacks
  const defaultConfig = {
    container: null,
    items: null,
    autoCloseOnOpen: true,
    arrow: true,
    callbacks: {
      onInit: () => {},
      onOpen: () => {},
      onClose: () => {},
      onUpdate: () => {}
    }
  };

  // TODO: see if this needs to be saved...
  let config = userConfig;
  let configsArray = [];

  const register = element => {
    let newConfig = Object.assign(defaultConfig, config);

    // TODO: Check why .container is getting set
    //       and if there is overlap with state
    //       if it is just to ID the config... there are better ways
    newConfig.container = element;

    configsArray.push(newConfig);

    return newConfig;
  };

  const getConfig = element =>
    configsArray.find(config => config.container === element);

  // TODO: write an update config function

  // Return a function that allows for the easy fetching of the config
  return { getConfig, register };
};

export default configFactory;
