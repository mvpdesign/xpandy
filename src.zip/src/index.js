import Xpandy from "./xpandy";

const xpander = new Xpandy(".Feed-wrapper", {
  arrow: false
});
